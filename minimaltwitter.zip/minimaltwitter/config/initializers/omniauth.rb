Rails.application.config.middleware.use OmniAuth::Builder do
  provider :twitter, "LaCMqJn5OEuBGISGA3X0UO5tM", "aVrramwh6mmnDawdFLMHyed4v1gqtRuiA7DMSO3KQUxFkohDq1", client_options: { ssl: { verify: !Rails.env.development? } }
end